import { useEffect, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
const apiUrl = "http://localhost:3000/task"


function App() {
  const [count, setCount] = useState(0)
  const [tasks, setTasks] = useState([])
  const [taskName, setTaskName] = useState("")
  const [openModal, setOpenModal] = useState(false)
  const [currentTask, setCurrentTask] = useState(null)

  const getTasks = async() => {
    const response = await fetch(apiUrl)
    const data = await response.json()

    setTasks(data)
  }
  const addTask = async() => {
    const res = await fetch(apiUrl, {
      method: "POST",
      body: tasks
    })
    console.log("post", res)
    await getTasks()
  }
  const handleOpenModal = async() => {
    setOpenModal(false)
    await getTasks()
  }
  const deleteTask = async(id) => {
    const res = await fetch(`${apiUrl}/${id}`, {
      method: "DELETE"
    })
    console.log("delete", res)
    await getTasks()
  }


  
  
  useEffect(() => {
    getTasks()
  }, [])
  useEffect(() => {
    console.log(tasks)
  })
  return (
    <>
    <input onChange={(e) => setTaskName(e.target.value)} value={taskName} />
    <button onClick={(e) => addTask()} type='button'>Add task</button>
    <button type='button'>Delete task</button>
      {tasks.map(task => {
        return <div className='task'><span>{task.taskName}</span><button type="button" onClick={() => {deleteTask(task.id)}}>Delete</button><button type='button' onClick={() => {setCurrentTask(task); setOpenModal(true)}}>Edit</button></div>
      })}
    {openModal && <EditTaskModal handleOpenModal={handleOpenModal} taskName={currentTask.taskName} id={currentTask.id} checked={currentTask.checked}/>}

    </>

  )
}
const EditTaskModal = (props) => {
  const [taskName, setTaskName] = useState(props.taskName)
  const [checked,setChecked] = useState(props.checked)
useEffect(() => {
  console.log("checked", checked)
})
  const editTask = async(id) => {
 
    const res = await fetch(`${apiUrl}/${id}`, {
      method: "PUT",
      body: {taskName, checked}
    })
    console.log("editing", taskName, checked)

    await props.handleOpenModal()
    console.log("put", res)
  }

  return <div class="editModal">
    <input onChange={(e) => setTaskName(e.target.value)} value={taskName} placeholder='task name'/>
    <input type='checkbox' value={checked} checked={checked} onChange={(e) => { setChecked(e.target.value)}}/>
    <button type='button' onClick={(e) => { editTask(props.id)}}>edit</button>
  </div>
}
export default App
