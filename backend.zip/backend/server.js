const express = require("express")
const cors = require("cors")
const app = express()
const data = [{
    id: 1,  
    taskName: 'test',
    checked: false
}]
app.use(cors())
app.use(express.json()) 
app.get('/task', (req, res) => {
res.json(data)
})
app.post('/task', (req, res, next) => {
const { example } = req.body
//validate data here
if(valid) {
    next()
} else {
    return res.status(400).json({message: "Bad request data is invalid"})
}
}, (req, res) => {
const { taskName, checked} = req.body
const newTask = { id: data.length + 1, taskName, checked}
data.push(newTask)

res.status(200).json(task)
})
app.put('/task/:id', (req, res) => {
const task = data.find(d => d.id == req.params.id)
const index = data.findIndex(c => c.id == req.params.id)
const { taskName, checked } = req.body
console.log("teeest", req.body)
task.taskName = taskName
task.isCompleted = checked
data[index] = task
res.status(200).json(task)
})
app.delete('/task/:id', (req, res) => {
    console.log(req)
})
app.listen(3000, (error) => {
})